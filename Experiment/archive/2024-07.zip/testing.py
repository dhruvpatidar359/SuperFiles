import os
import docx
from odf.opendocument import load
from odf.text import P
import google.generativeai as genai

genai.configure(api_key="//Enter your key here")
# genai.configure(api_key=os.environ["GEMINI_API_KEY"])

generation_config = {
  "temperature": 1,
  "top_p": 0.95,
  "top_k": 64,
  "max_output_tokens": 8192,
  "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
  model_name="gemini-1.5-flash",
  generation_config=generation_config,
  # safety_settings = Adjust safety settings
  # See https://ai.google.dev/gemini-api/docs/safety-settings
)

chat_session = model.start_chat(
  history=[
  ]
)


def list_files_in_directory(directory):
    files = []
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        if os.path.isfile(file_path):
            files.append(file_path)
    return files

def read_docx_file(file_path, chars_to_read):
    doc = docx.Document(file_path)
    full_text = []
    chars_read = 0
    for paragraph in doc.paragraphs:
        if chars_read >= chars_to_read:
            break
        text = paragraph.text
        full_text.append(text)
        chars_read += len(text)
    return '\n'.join(full_text)[:chars_to_read]

def read_odt_file(file_path, chars_to_read):
    doc = load(file_path)
    paragraphs = doc.getElementsByType(P)
    full_text = []
    chars_read = 0
    for paragraph in paragraphs:
        if chars_read >= chars_to_read:
            break
        text = ''.join([node.data for node in paragraph.childNodes if node.nodeType == node.TEXT_NODE])
        full_text.append(text)
        chars_read += len(text)
    return '\n'.join(full_text)[:chars_to_read]

def read_text_file(file_path, chars_to_read):
    with open(file_path, 'r') as f:
        return f.read(chars_to_read)

def print_file_contents(files, chars_per_page=3000, pages=5):
    chars_to_read = chars_per_page * pages
    prompt_to_send = """The following is a list of file contents, along with their metadata. For each file, provide a summary of the contents.
    The purpose of the summary is to organize files based on their content. To this end provide a concise but informative summary.
    Try to make the summary as specific to the file as possible. Here's the content of file :"""
    for file in files:
        print(f"\nContents of {file}:")
        try:
            if file.endswith('.docx'):
                content = read_docx_file(file, chars_to_read)
            elif file.endswith('.odt'):
                content = read_odt_file(file, chars_to_read)
            else:
                content = read_text_file(file, chars_to_read)
            #print(content)
            prompt_to_send = prompt_to_send + content
            response = chat_session.send_message(prompt_to_send)
            print(response.text)
        except Exception as e:
            print(f"Could not read file {file} due to {e}")

directory = '/home/jarvis/Major_TEST'
files = list_files_in_directory(directory)

for file in files:
    print(file)

print_file_contents(files)
